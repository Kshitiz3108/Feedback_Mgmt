package com.cg.project.dto;

public class TrainingPartIDTO {
	private int training_code;
	private int participant_id;
	public int getTraining_code() {
		return training_code;
	}
	public void setTraining_code(int training_code) {
		this.training_code = training_code;
	}
	public int getParticipant_id() {
		return participant_id;
	}
	public void setParticipant_id(int participant_id) {
		this.participant_id = participant_id;
	}
	
}
